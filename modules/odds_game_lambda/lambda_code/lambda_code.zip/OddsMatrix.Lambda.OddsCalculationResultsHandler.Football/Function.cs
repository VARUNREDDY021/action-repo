using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.Core;
using Amazon.Lambda.SNSEvents;
using Amazon.Runtime;
using OddsMatrix.Common.Models;
using System.Text.Json;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace OddsMatrix.Lambda.OddsCalc.Football;

public class Function
{
    private readonly IAmazonDynamoDB _dynamoClient;
    private readonly string _tableName = "dev-odds-football"; // Configure as needed

    /// <summary>
    /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
    /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
    /// region the Lambda function is executed in.
    /// </summary>
    public Function()
    {
        var Credentials = new BasicAWSCredentials("AKIAYDIIPV7GUW727QFG",
                "I1A5/Uxvh45uDGW0Bne65FO8sIT5FfzTN8vRXSuM");
        var dynamoConfig = new AmazonDynamoDBConfig
        {
            RegionEndpoint = RegionEndpoint.GetBySystemName("us-east-1")
        };

        _dynamoClient = new AmazonDynamoDBClient(Credentials, dynamoConfig);
    }


    /// <summary>
    /// This method is called for every Lambda invocation. This method takes in an SNS event object and can be used 
    /// to respond to SNS messages.
    /// </summary>
    /// <param name="evnt">The event for the Lambda function handler to process.</param>
    /// <param name="context">The ILambdaContext that provides methods for logging and describing the Lambda environment.</param>
    /// <returns></returns>
    public async Task FunctionHandler(SNSEvent evnt, ILambdaContext context)
    {
        foreach (var record in evnt.Records)
        {
            try
            {
                // Parse the message from SNS
                var message = JsonSerializer.Deserialize<GameMessage>(record.Sns.Message);

                // Create DynamoDB item
                var item = new Dictionary<string, AttributeValue>
                {
                    ["event_id"] = new AttributeValue { S = message.EventId.ToString() },
                    ["Sport"] = new AttributeValue { S = message.Sport },
                    ["League"] = new AttributeValue { S = message.League },
                    ["GameName"] = new AttributeValue { S = message.GameName },
                    ["HomeTeam"] = new AttributeValue { S = message.HomeTeam },
                    ["AwayTeam"] = new AttributeValue { S = message.AwayTeam },

                    ["HomeTeamId"] = new AttributeValue { N = message.HomeTeamId.ToString() },
                    ["AwayTeamId"] = new AttributeValue { N = message.AwayTeamId.ToString() },

                    ["Status"] = new AttributeValue { S = message.Status.ToString() },

                    ["MoneylineOddsAAmerican"] = new AttributeValue { S = message.Moneyline.OddsAAmerican.ToString() },
                    ["MoneylineOddsADecimal"] = new AttributeValue { S = message.Moneyline.OddsADecimal.ToString() },
                    ["MoneylineOddsHAmerican"] = new AttributeValue { S = message.Moneyline.OddsHAmerican.ToString() },
                    ["MoneylineOddsHDecimal"] = new AttributeValue { S = message.Moneyline.OddsHDecimal.ToString() },

                    ["SpreadOddsAAmerican"] = new AttributeValue { S = message.Spread.OddsAAmerican.ToString() },
                    ["SpreadOddsADecimal"] = new AttributeValue { S = message.Spread.OddsADecimal.ToString() },
                    ["SpreadOddsHAmerican"] = new AttributeValue { S = message.Spread.OddsHAmerican.ToString() },
                    ["SpreadOddsHDecimal"] = new AttributeValue { S = message.Spread.OddsHDecimal.ToString() },

                    ["SpreadA"] = new AttributeValue { S = message.Spread.SpreadA.ToString() },
                    ["SpreadH"] = new AttributeValue { S = message.Spread.SpreadH.ToString() },

                    ["TotalOddsOverAmerican"] = new AttributeValue { S = message.Total.OddsOverAmerican.ToString() },
                    ["TotalOddsOverDecimal"] = new AttributeValue { S = message.Total.OddsOverDecimal.ToString() },
                    ["TotalOddsUnderAmerican"] = new AttributeValue { S = message.Total.OddsUnderAmerican.ToString() },
                    ["TotalOddsUnderDecimal"] = new AttributeValue { S = message.Total.OddsUnderDecimal.ToString() },
                    ["TotalTotal"] = new AttributeValue { S = message.Total.Total.ToString() },


                    ["StartTime"] = new AttributeValue { S = message.StartTime.ToString() }


                    //["MoneyLineHome"] = new AttributeValue { N = message.MoneyLineHome.ToString() },
                    //["MoneyLineAway"] = new AttributeValue { N = message.MoneyLineAway.ToString() },
                    //["GameTime"] = new AttributeValue { S = message.GameTime.ToString("o") }
                };

                // Write to DynamoDB
                var request = new PutItemRequest
                {
                    TableName = _tableName,
                    Item = item
                };

                await _dynamoClient.PutItemAsync(request);
                context.Logger.LogInformation($"Successfully processed game {message.EventId}");
            }
            catch (Exception ex)
            {
                context.Logger.LogError($"Error processing SNS record: {ex.Message}");
                throw;
            }
        }
    }

    
}