using Amazon;
using Amazon.DynamoDBv2;
using Amazon.Lambda.APIGatewayEvents;
using Amazon.Lambda.Core;
using Amazon.Lambda.S3Events;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.SimpleNotificationService;
using io.pick.winners;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Collections;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace OddsMatrix.Lambda.InitialDump;

public class Function
{

    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<Function> _logger;
    private readonly IAmazonS3 _s3Client;
    private readonly DynamoDBHandler _dynamoDBHandler;
    private const int BATCH_SIZE = 3000;
    private const int MAX_CONCURRENT_BATCHES = 3;  


    public Function()
    {
        var services = ConfigureServices();
        _serviceProvider = services.BuildServiceProvider();

        _logger = _serviceProvider.GetRequiredService<ILogger<Function>>();
        _s3Client = _serviceProvider.GetRequiredService<IAmazonS3>();
        _dynamoDBHandler = _serviceProvider.GetRequiredService<DynamoDBHandler>();
    }

    private IServiceCollection ConfigureServices()
    {
        var services = new ServiceCollection();

        services.AddLogging(builder =>
        {
            builder.ClearProviders();
            builder.AddConsole();
            builder.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Error);
        });

        // Configure AWS Services
        string awsAccessKey = Environment.GetEnvironmentVariable("AWSAccesskey") ?? "AKIAYDIIPV7GUW727QFG";
        string awsSecretKey = Environment.GetEnvironmentVariable("AWSSecretKey") ?? "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" ;
        string awsRegion = Environment.GetEnvironmentVariable("AWSRegion") ?? "us-east-1";
        string connectionString = Environment.GetEnvironmentVariable("MARIADB_CONNECTION_STRING") ?? "Server=dev-pickwinners-oddsmatrix-db.cbr44ho3a84i.us-east-1.rds.amazonaws.com;Port=3306;Database=odd-matrix-poc;User=admin;Password=KwwLCSbM8H(W4v|gSZ<K>6(AmZH3;";
         


        var credentials = new BasicAWSCredentials(awsAccessKey, awsSecretKey);

        services.AddSingleton<IAmazonS3>(sp =>
        {
            var s3Config = new AmazonS3Config
            {
                RegionEndpoint = RegionEndpoint.GetBySystemName(awsRegion)
            };
            return new AmazonS3Client(credentials, s3Config);
        });

        services.AddSingleton<IAmazonDynamoDB>(sp =>
        {
            var dynamoConfig = new AmazonDynamoDBConfig
            {
                RegionEndpoint = RegionEndpoint.GetBySystemName(awsRegion)
            };
            return new AmazonDynamoDBClient(credentials, dynamoConfig);
        });

        // Add DynamoDBHandler
        services.AddSingleton<DynamoDBHandler>();

        // Configure DbContext with optimized pooling
        services.AddDbContextPool<AppDbContext>(options =>
        {
  
            // Ensure connection string has pool settings
            if (!connectionString.Contains("Maximum Pool Size", StringComparison.OrdinalIgnoreCase))
            {
                connectionString = $"{connectionString};Maximum Pool Size=100;Minimum Pool Size=10;Connection Lifetime=60;Default Command Timeout=60;";
            }

            options.UseMySql(
                connectionString,
                ServerVersion.AutoDetect(connectionString),
                mySqlOptions =>
                {
                    // Configure connection resilience
                    mySqlOptions.EnableRetryOnFailure(
                        maxRetryCount: 3,
                        maxRetryDelay: TimeSpan.FromSeconds(5),
                        errorNumbersToAdd: null
                    );

                    // Performance optimizations
                    mySqlOptions.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery);                    
                }
            );

        });

        return services;
    }

    public async Task<APIGatewayProxyResponse> FunctionHandler(S3Event s3Event, ILambdaContext context)
    {
        var fileName = string.Empty;
        try
        {
            var record = s3Event.Records[0]; // We're processing single file
            var bucket = record.S3.Bucket.Name;
            var key = record.S3.Object.Key;
            var batchId = key.Split('_').LastOrDefault()?.Replace(".json", "");
            var entityName = ExtractEntityName(key);
            fileName = key;

            _logger.LogWarning($"Processing file {key} from bucket {bucket}");

            // Get the S3 object
            using var response = await _s3Client.GetObjectAsync(bucket, key);
            using var streamReader = new StreamReader(response.ResponseStream);

            var recordsProcessed = 0;
            var startTime = DateTime.UtcNow;

            using var semaphore = new SemaphoreSlim(MAX_CONCURRENT_BATCHES);
            var tasks = new List<Task>();

            // Process the stream in batches
            await foreach (var batch in ProcessStreamInBatchesAsync(streamReader, entityName))
            {
                await semaphore.WaitAsync();
                var task = Task.Run(async () =>
                {
                    try
                    {
                        using var scope = _serviceProvider.CreateScope();
                        using var dbContext = scope.ServiceProvider.GetRequiredService<AppDbContext>();

                        await InsertBatchAsync(dbContext, batch);
                        Interlocked.Add(ref recordsProcessed, batch.Count);

                        _logger.LogDebug($"Processed batch of {batch.Count} records");
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                });

                tasks.Add(task);


            }

            await Task.WhenAll(tasks);


            var duration = DateTime.UtcNow - startTime;
            _logger.LogInformation($"Processed {recordsProcessed} records in {duration.TotalSeconds:F2} seconds");

            // Update DynamoDB status
            await UpdateDynamoDB(batchId);

            return new APIGatewayProxyResponse
            {
                StatusCode = 200,
                Body = JsonSerializer.Serialize(new
                {
                    message = "Successfully processed file " + fileName,
                    recordsProcessed,
                    processingTimeSeconds = duration.TotalSeconds
                })
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing S3 event for file " + fileName);
            return new APIGatewayProxyResponse
            {
                StatusCode = 500,
                Body = JsonSerializer.Serialize(new { error = "Error processing S3 event for file " + fileName + " " + ex.Message })
            };
        }
    }

    private async IAsyncEnumerable<List<object>> ProcessStreamInBatchesAsync(
        StreamReader streamReader,
        string entityName)
    {
        var type = GetTypeByName(entityName);
        if (type == null)
        {
            _logger.LogError($"Could not resolve type for entity name: {entityName}");
            throw new InvalidOperationException($"Type not found for entity: {entityName}");
        }

        var batch = new List<object>(BATCH_SIZE);
        var jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            WriteIndented = false // Disable pretty printing for performance
        };

        using var jsonDocument = await JsonDocument.ParseAsync(streamReader.BaseStream);
        var elements = jsonDocument.RootElement.EnumerateArray();

        foreach (var element in elements)
        {

            var entity = JsonSerializer.Deserialize(element.GetRawText(), type, jsonSerializerOptions);
            if (entity != null)
            {
                batch.Add(entity);
            }

            if (batch.Count >= BATCH_SIZE)
            {
                yield return batch;
                batch = new List<object>(BATCH_SIZE);
            }
        }

        if (batch.Any())
        {
            yield return batch;
        }
    }

    private async Task InsertBatchAsync(AppDbContext dbContext, List<object> batch)
    {
        try
        {
            foreach (var entity in batch)
            {
                var dbSetProperty = dbContext.GetType().GetProperties()
                    .FirstOrDefault(p => p.PropertyType.IsGenericType &&
                                       p.PropertyType.GetGenericTypeDefinition() == typeof(DbSet<>) &&
                                       p.PropertyType.GetGenericArguments()[0] == entity.GetType());

                if (dbSetProperty != null)
                {
                    var dbSet = dbSetProperty.GetValue(dbContext);
                    dbSet.GetType().GetMethod("Add")?.Invoke(dbSet, new[] { entity });
                }
            }

            await dbContext.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error inserting batch of {batch.Count} records");
            throw;
        }
    }

    private async Task UpdateDynamoDB(string batchId)
    {
        try
        {
            _logger.LogWarning("Calling DynamoDB");
           await _dynamoDBHandler.UpdateProcessingStatus(batchId, true, "PROCESSED");
            _logger.LogWarning("Completed DynamoDB");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to update DynamoDB status");
            // Log but don't throw - we don't want to fail the whole operation if just the status update fails
        }
    }

    public static T DeserializeJsonToObject<T>(string jsonContent, JsonSerializerOptions options = null)
    {
        options ??= new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        return JsonSerializer.Deserialize<T>(jsonContent, options);
    }

    public static IList<object> DeserializeJsonToList(string jsonContent, Type entityType)
    {
        // Create a List<> of the specified type dynamically
        var listType = typeof(List<>).MakeGenericType(entityType);

        // Deserialize the JSON content to the dynamically created list type
        var deserializedList = JsonSerializer.Deserialize(jsonContent, listType, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        });

        var objectList = (IList)deserializedList; // Cast to non-generic IList first
        return objectList.Cast<object>().ToList(); // Convert to IList<object>
    }

    public static string ExtractEntityName(string fileName)
    {
        fileName= Path.GetFileNameWithoutExtension(fileName);
        return fileName?.Split('_').FirstOrDefault();
    }

    private Type GetTypeByName(string typeName)
    {
        try
        {
            _logger.LogWarning($"Searching for type: {typeName}");

            // First, try to find the type in the SEPC-Connector assembly
            var assemblyPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SEPC-Connector.dll");
            if (File.Exists(assemblyPath))
            {
                _logger.LogWarning($"Loading assembly from: {assemblyPath}");
                var assembly = Assembly.LoadFrom(assemblyPath);

                // Look for exact type name match first
                var type = assembly.GetTypes()
                    .FirstOrDefault(t => t.Name.Equals(typeName, StringComparison.OrdinalIgnoreCase));

                if (type != null)
                {
                    _logger.LogWarning($"Found type {type.FullName} in SEPC-Connector.dll");
                    return type;
                }

                // If not found, try looking for types that end with the type name
                // This helps when the file name doesn't include the full namespace
                type = assembly.GetTypes()
                    .FirstOrDefault(t => t.Name.EndsWith(typeName, StringComparison.OrdinalIgnoreCase));

                if (type != null)
                {
                    _logger.LogWarning($"Found type {type.FullName} in SEPC-Connector.dll using suffix match");
                    return type;
                }
            }

            // Then try current domain assemblies if not found in SEPC-Connector
            var types = AppDomain.CurrentDomain.GetAssemblies()
                .Where(a => !a.IsDynamic)
                .SelectMany(a =>
                {
                    try
                    {
                        return a.GetTypes();
                    }
                    catch (ReflectionTypeLoadException)
                    {
                        return Array.Empty<Type>();
                    }
                })
                .Where(t => !t.IsSystemType() && !t.FullName.StartsWith("System."))
                .ToList();

            // Look for exact type name match
            var domainType = types.FirstOrDefault(t => t.Name.Equals(typeName, StringComparison.OrdinalIgnoreCase));
            if (domainType != null)
            {
                _logger.LogWarning($"Found type {domainType.FullName} in loaded assemblies");
                return domainType;
            }

            // If not found, try looking for types that end with the type name
            domainType = types.FirstOrDefault(t => t.Name.EndsWith(typeName, StringComparison.OrdinalIgnoreCase));
            if (domainType != null)
            {
                _logger.LogWarning($"Found type {domainType.FullName} in loaded assemblies using suffix match");
                return domainType;
            }

            _logger.LogError($"Type {typeName} not found in any assembly");
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error resolving type: {typeName}");
            throw;
        }
    }

    //private Type GetTypeByName(string typeName)
    //{
    //    try
    //    {
    //        _logger.LogWarning($"Searching for type: {typeName}");

    //        // First try current domain assemblies
    //        var type = AppDomain.CurrentDomain.GetAssemblies()
    //            .SelectMany(a => a.GetTypes())
    //            .FirstOrDefault(t => t.Name.Equals(typeName, StringComparison.OrdinalIgnoreCase));

    //        if (type != null)
    //        {
    //            _logger.LogWarning($"Found type {type.FullName} in loaded assemblies");
    //            return type;
    //        }

    //        // Try to load from SEPC-Connector.dll
    //        var assemblyPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SEPC-Connector.dll");
    //        if (File.Exists(assemblyPath))
    //        {
    //            _logger.LogWarning($"Loading assembly from: {assemblyPath}");
    //            var assembly = Assembly.LoadFrom(assemblyPath);
    //            type = assembly.GetTypes()
    //                .FirstOrDefault(t => t.Name.Equals(typeName, StringComparison.OrdinalIgnoreCase));

    //            if (type != null)
    //            {
    //                _logger.LogWarning($"Found type {type.FullName} in SEPC-Connector.dll");
    //                return type;
    //            }
    //        }

    //        _logger.LogError($"Type {typeName} not found");
    //        return null;
    //    }
    //    catch (Exception ex)
    //    {
    //        _logger.LogError(ex, $"Error resolving type: {typeName}");
    //        throw;
    //    }
    //}
}


public static class TypeExtensions
{
    public static bool IsSystemType(this Type type)
    {
        return type.Namespace != null &&
               (type.Namespace.StartsWith("System") ||
                type.Namespace.StartsWith("Microsoft") ||
                type.Assembly.GetName().Name.StartsWith("System") ||
                type.Assembly.GetName().Name.StartsWith("Microsoft"));
    }
}