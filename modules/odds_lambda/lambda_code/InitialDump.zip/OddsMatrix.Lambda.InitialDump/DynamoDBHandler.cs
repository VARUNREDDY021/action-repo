﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace OddsMatrix.Lambda.InitialDump
{
    public class DynamoDBHandler
    {
        private readonly DynamoDBContext _context;
        private readonly ILogger<DynamoDBHandler> _logger;

        public DynamoDBHandler(IAmazonDynamoDB dynamoDBClient, ILogger<DynamoDBHandler> logger)
        {
            _context = new DynamoDBContext(dynamoDBClient);
            _logger = logger;
        }

        public async Task UpdateProcessingStatus(string batchId, bool isProcessed, string status)
        {
            try
            {
                _logger.LogInformation("Calling DynamoDB");
                _logger.LogInformation(_context.ToString());

                var fileStatus = await _context.LoadAsync<FileProcessingStatus>(batchId);
                _logger.LogInformation("Call completed with DynamoDB");
                if (fileStatus != null)
                {
                    fileStatus.IsProcessed = isProcessed;
                    fileStatus.ProcessingStatus = status;
                    await _context.SaveAsync(fileStatus);
                    _logger.LogInformation($"Updated processing status for batch {batchId} to {status}");
                }
                else
                {
                    _logger.LogWarning($"No record found for batch {batchId} in DynamoDB");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating processing status for batch {batchId}");
                throw;
            }
        }
    }

    [DynamoDBTable("file_processing_status")]
    public class FileProcessingStatus
    {
        [DynamoDBHashKey("batch_id")]
        public string BatchId { get; set; }

        [DynamoDBProperty("file_key")]
        public string FileKey { get; set; }

        [DynamoDBProperty("entity_type")]
        public string EntityType { get; set; }

        [DynamoDBProperty("timestamp")]
        public DateTime Timestamp { get; set; }

        [DynamoDBProperty("is_processed")]
        public bool IsProcessed { get; set; }

        [DynamoDBProperty("processing_status")]
        public string ProcessingStatus { get; set; }

        [DynamoDBProperty("entity_count")]
        public int EntityCount { get; set; }
    }
}