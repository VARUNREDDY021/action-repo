using Amazon.Lambda.Core;
using Amazon.Lambda.SNSEvents;
using Amazon.Lambda.Logging.AspNetCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using OddsMatrix.LambdaLayer.OddsCalculation;
using OddsMatrix.LambdaLayer;
using System.Text.Json;
using OddsMatrix.LambdaLayer.OddsCalculation.Models;
using Amazon.SimpleNotificationService.Model;
using Amazon.SimpleNotificationService;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace OddsMatrix.Lambda.OddsCalculation;

public class Function
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<Function> _logger;
    private readonly IAmazonSimpleNotificationService _snsClient;
    private readonly string _snsTopicArn;

    /// <summary>
    /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
    /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
    /// region the Lambda function is executed in.
    /// </summary>
    public Function()
    {
        // Set up configuration
        var configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: true)
            .AddEnvironmentVariables()
            .Build();

        // Set up dependency injection
        var services = new ServiceCollection();

        // Add logging
        services.AddLogging(logging =>
        {
            logging.AddLambdaLogger();
            logging.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Information);
        });

        // Add odds calculation services
        services.AddOddsCalculation(options =>
        {
            options.ConnectionString= Environment.GetEnvironmentVariable("MARIADB_CONNECTION_STRING");
            //options.ConnectionString = "Server=dev-pickwinners-oddsmatrix-db.cbr44ho3a84i.us-east-1.rds.amazonaws.com;Port=3306;Database=odd-matrix-poc;User=admin;Password=KwwLCSbM8H(W4v|gSZ<K>6(AmZH3;";
        });

        // Build service provider
        _serviceProvider = services.BuildServiceProvider();
        _logger = _serviceProvider.GetRequiredService<ILogger<Function>>();

        _snsClient = new AmazonSimpleNotificationServiceClient();
        _snsTopicArn = Environment.GetEnvironmentVariable("ODDS_RESULT_SNS_TOPIC_ARN_BASKET_BALL")
            ?? throw new InvalidOperationException("ODDS_RESULT_SNS_TOPIC_ARN not configured");


    }


    public async Task<OddsCalculationResponse> FunctionHandler(SNSEvent snsEvent, ILambdaContext context)
    {
        try
        {
            context.Logger.LogInformation($"Processing SNS event with {snsEvent.Records.Count} records");

            foreach (var record in snsEvent.Records)
            {
                var message = record.Sns.Message;
                context.Logger.LogInformation($"Processing message: {message}");

                // Parse the SNS message
                // for local testing for initial data dump, the value hardcoded
                //if (message.Contains("All files processed"))
                //{ 
                    //var request = JsonSerializer.Deserialize<SNSRequest>(message);
                    //if (request == null)
                    //{
                    //    return new OddsCalculationResponse
                    //    {
                    //        Success = false,
                    //        Message = "Invalid request format"
                    //    };
                    //}
                //}
                var request = new SNSRequest() { SportId= 8, StartDate=DateTime.Now.AddDays(-10), EndDate=DateTime.Now };
                // Get the odds calculation service
                var oddsService = _serviceProvider.GetRequiredService<OddsCalculationService>();

                // Calculate odds for a specific sport and for a given date ranges
                var result = await oddsService.CalculateOddsAsync(
                    request.SportId,request.StartDate,request.EndDate);

                context.Logger.LogInformation($"Successfully calculated odds for sport {request.SportId}");

                //SportEventOdds result1 = new SportEventOdds();

                //result1.EventId =1;
                //result1.Sport ="8";
                //result1.League ="league";
                //result1.GameName= "My games";
                //result1.HomeTeam ="Home";
                //result1.AwayTeam = "Away";
                //result1.StartTime = System.DateTime.Now.ToString();
                //_logger.LogInformation("Topic name : "  + _snsTopicArn);
                //if (string.IsNullOrEmpty(_snsTopicArn))
                //{
                //    _snsTopicArn = "arn:aws:sns:us-east-1:556752941005:dev-odds-sns-BasketBall";
                //}

                //try
                //{
                //    // Publish to SNS
                //    var publishRequest = new PublishRequest
                //    {
                //        TopicArn = _snsTopicArn,
                //        Message = JsonSerializer.Serialize(result1)
                //    };

                //    _logger.LogInformation("SNS message " + publishRequest.Message);

                //    await _snsClient.PublishAsync(publishRequest);
                //    _logger.LogInformation($"Published odds calculation results to SNS for event {result1.EventId}");

                //}
                //catch (Exception ex)
                //{
                //    // Publish to SNS
                //    var publishRequest = new PublishRequest
                //    {
                //        TopicArn = "dev-odds-sns-BasketBall",
                //        Message = JsonSerializer.Serialize(result1)
                //    };

                //    await _snsClient.PublishAsync(publishRequest);
                //    _logger.LogInformation($"2 Published odds calculation results to SNS for event {result1.EventId}");

                //}


                 
                if (result.Success && result.Odds.Any())
                {
                    // Prepare data for DynamoDB storage
                    foreach (var odds in result.Odds)
                    {
                        // Send the payload what we wanted to insert into DynamoDB 
                        var dynamoDbData = new SportEventOdds
                        {
                            EventId = odds.EventId,
                            Sport = odds.Sport,
                            League = odds.League,
                            GameName = odds.GameName,
                            HomeTeam = odds.HomeTeam,
                            AwayTeam = odds.AwayTeam,
                            StartTime = odds.StartTime,
                            AwayTeamId =odds.AwayTeamId,
                            HomeTeamId = odds.HomeTeamId,
                            Moneyline = odds.Moneyline,
                            Spread= odds.Spread,
                            Status=odds.Status,
                            Total=odds.Total
                             
                        };

                        // Publish to SNS
                        var publishRequest = new PublishRequest
                        {
                            TopicArn = _snsTopicArn,
                            Message = JsonSerializer.Serialize(dynamoDbData)
                        };

                        await _snsClient.PublishAsync(publishRequest);
                        _logger.LogInformation($"Published odds calculation results to SNS for event {odds.EventId}");
                    }
                }
                




                return new OddsCalculationResponse
                {
                    Success = true,
                    Message = "Odds calculated successfully",
                    Result = result
                };
            }

            return new OddsCalculationResponse
            {
                Success = false,
                Message = "No SNS records to process"
            };
        }
        catch (Exception ex)
        {
            context.Logger.LogError($"Error processing request: {ex.Message}");
            context.Logger.LogError(ex.StackTrace);

            return new OddsCalculationResponse
            {
                Success = false,
                Message = $"Error processing request: {ex.Message}"
            };
        }

    }

    public class SNSRequest
    {
        public int SportId { get; set; } = 8;  // Default to 8 if not specified, for basketball
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }

    public class OddsCalculationResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public SportEventOddsResult Result { get; set; }
    }
}
